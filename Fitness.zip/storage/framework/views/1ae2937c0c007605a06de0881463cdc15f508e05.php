<section class="info-panel text feature-list home-feature-list">
    <div class="container">
        <div class="container -medium_medium">
            <h2 class="heading -large -light">
                Our application is helping many to achieve their goals and stay healthy and strong inorder to carry
                out their daily life tasks easily and more effiectiently
            </h2>
        </div>
        <div class="container -narrow">
            <ul>
                <li class="powered">
                    <figure>35+</figure>
                    <p class="no-pad -tight">35+ workouts completed each month</p>
                </li>
                <li class="programs">
                    <figure>50+</figure>
                    <p class="no-pad -tight">50+ free workout videos for every fitness level + effective &amp;
                        affordable workout programs</p>
                </li>
                <li class="workouts">
                    <figure>10+</figure>
                    <p class="no-pad -tight">Professional and experienced trainers and dieticians helping people
                        achieve their fitness
                        &amp; health goals.</p>
                </li>
            </ul>
        </div>
    </div>
</section>
<?php /**PATH /home/behlole/Desktop/fitness/Fitness/resources/views/sections/info-panel.blade.php ENDPATH**/ ?>