<section class="routine">
    <div class="container">
        <h1>
            We Offer Plans accoring to your Needs
        </h1>
        <h4>
            So get in touch and Opt for any plan that suites your need.
        </h4>
        <div class="routine-plan">
            <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single_plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="plan1">
                    <div class="plan-img">
                        <img src="<?php echo e(asset('storage/'.$single_plan->image_url)); ?>" alt="Plan-1">
                    </div>
                    <h1>
                        <?php echo e($single_plan->name); ?>

                    </h1>
                    <p>
                        <?php echo e($single_plan->small_description); ?>

                    </p>
                    <a href="weekly" class="btn">View Plan</a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
        </div>
    </div>
</section>
<?php /**PATH /home/behlole/Desktop/fitness/Fitness/resources/views/sections/routine.blade.php ENDPATH**/ ?>