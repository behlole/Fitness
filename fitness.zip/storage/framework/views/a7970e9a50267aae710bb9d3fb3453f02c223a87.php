<section class="main-fitness">
    <div class="container">
        <div class="fitness">
            <div class="fitness-text">
                <h1>
                    FITNESS
                </h1>
                <p>
                    This is a fitness related web-based application. Our project will help those people who want to
                    perform fitness workout at home especially women and busy person or such people who cannot pay
                    gym
                    fee. such type of people can start their fitness journey
                    by using this fitness app. This system provides online training facilities and online dietitian
                    facilities.
                </p>
            </div>
            <div class="fitness-img">
                <img src="<?php echo e(asset('images/jenny-hill-mQVWb7kUoOE-unsplash.jpg')); ?>" alt="FitnessImage">
            </div>
        </div>

    </div>
</section>
<?php /**PATH /home/behlole/FitnessLaravel/Fitness/resources/views/sections/main-section.blade.php ENDPATH**/ ?>