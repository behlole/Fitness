<section class="routine">
    <div class="container">
        <h1>
            We Offer Plans accoring to your Needs
        </h1>
        <h4>
            So get in touch and Opt for any plan that suites your need.
        </h4>
        <div class="routine-plan">
            <div class="plan1">
                <div class="plan-img">
                    <img src="<?php echo e(asset('images/plan-1.jpg')); ?>" alt="Plan-1">
                </div>
                <h1>
                    Are You Up For Our Weekly Plan
                </h1>
                <a href="weekly" class="btn">View Plan</a>
            </div>
            <div class="plan2">
                <div class="plan-img">
                    <img src="<?php echo e(asset('images/plan-2.jpg')); ?>" alt="Plan-2">
                </div>
                <h1>
                    Are You Up For Our 1 Month Plan
                </h1>
                <button class="btn">View Plan</button>
            </div>
            <div class="plan3">
                <div class="plan-img">
                    <img src="<?php echo e(asset('images/plan-3.jpg')); ?>" alt="Plan-3">
                </div>
                <h1>
                    Are You Up For Our 3 Month Plan
                </h1>
                <button class="btn">View Plan</button>
            </div>
        </div>
    </div>
</section>
<?php /**PATH /home/behlole/FitnessLaravel/Fitness/resources/views/sections/routine.blade.php ENDPATH**/ ?>